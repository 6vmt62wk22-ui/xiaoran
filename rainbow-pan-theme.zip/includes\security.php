<?php
/**
 * 安全增强函数库
 * 引入方式: include(ROOT.'includes/security.php');
 */

/* ── CSRF Token ── */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrf_check($token) {
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
function csrf_field() {
    return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">';
}

/* ── 安全重定向 ── */
function safe_redirect($url) {
    // 仅允许站内跳转
    $parsed = parse_url($url);
    if (isset($parsed['host']) && $parsed['host'] !== $_SERVER['HTTP_HOST']) {
        $url = '/';
    }
    header('Location: ' . $url);
    exit;
}

/* ── 请求频率限制 (基于 Session) ── */
function rate_limit($key, $max = 10, $window = 60) {
    $now = time();
    if (!isset($_SESSION['rate_' . $key])) {
        $_SESSION['rate_' . $key] = ['count' => 0, 'reset' => $now + $window];
    }
    $bucket = &$_SESSION['rate_' . $key];
    if ($now > $bucket['reset']) {
        $bucket = ['count' => 0, 'reset' => $now + $window];
    }
    $bucket['count']++;
    return $bucket['count'] <= $max;
}

/* ── 安全日志 ── */
function security_log($event, $detail = '') {
    $logDir = ROOT . 'data/';
    if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
    $line = date('Y-m-d H:i:s') . ' | ' . get_real_ip() . ' | ' . $event . ' | ' . $detail . PHP_EOL;
    @file_put_contents($logDir . 'security.log', $line, FILE_APPEND | LOCK_EX);
}

/* ── IP 黑名单检查 ── */
function is_ip_blocked($ip) {
    global $conf;
    if (empty($conf['blackip'])) return false;
    $blacklist = explode('|', $conf['blackip']);
    foreach ($blacklist as $blocked) {
        $blocked = trim($blocked);
        if (empty($blocked)) continue;
        // 支持 CIDR 前缀匹配
        if (strpos($blocked, '/') !== false) {
            if (cidr_match($ip, $blocked)) return true;
        } elseif ($ip === $blocked) {
            return true;
        }
    }
    return false;
}
function cidr_match($ip, $cidr) {
    list($subnet, $bits) = explode('/', $cidr);
    $mask = -1 << (32 - (int)$bits);
    return (ip2long($ip) & $mask) === (ip2long($subnet) & $mask);
}

/* ── 输入强化过滤 ── */
function sanitize_filename($name) {
    // 移除路径穿越字符和 null 字节
    $name = str_replace(["\0", '/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $name);
    $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name);
    $name = trim($name, " .\t\n\r");
    if (empty($name)) $name = 'unnamed';
    return $name;
}
function sanitize_int($val, $default = 0) {
    return is_numeric($val) ? intval($val) : $default;
}

/* ── 安全 Header 输出 ── */
function send_security_headers() {
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    // 仅 HTTPS 时启用 HSTS
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/* ── Session 安全 ── */
function secure_session_start() {
    if (session_status() === PHP_SESSION_NONE) {
        $cookieParams = session_get_cookie_params();
        session_set_cookie_params([
            'lifetime' => $cookieParams['lifetime'],
            'path'     => '/',
            'domain'   => $cookieParams['domain'],
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
    // Session 固定攻击防护
    if (!isset($_SESSION['_initiated'])) {
        session_regenerate_id(true);
        $_SESSION['_initiated'] = true;
    }
}
