<?php
/**
 * S3 兼容存储驱动
 * 支持 AWS S3 / Cloudflare R2 / MinIO / 阿里云OSS(S3兼容) 等
 */
namespace lib\Storage;
use \lib\IStorage;

class S3 implements IStorage
{
    private $config;
    private $bucket;
    private $region;
    private $endpoint;
    private $accessKey;
    private $secretKey;
    private $errmsg;
    private $filepath = 'file/';
    private $usePathStyle = false;

    public function __construct($config)
    {
        $this->config    = $config;
        $this->bucket    = $config['bucket'];
        $this->region    = $config['region'];
        $this->endpoint  = $config['endpoint'];
        $this->accessKey = $config['accessKey'];
        $this->secretKey = $config['secretKey'];
        // R2/MinIO 使用 path-style
        if (strpos($config['endpoint'], 'r2.cloudflarestorage.com') !== false ||
            strpos($config['endpoint'], 'localhost') !== false ||
            strpos($config['endpoint'], '127.0.0.1') !== false) {
            $this->usePathStyle = true;
        }
    }

    public function getClient()
    {
        return $this;
    }

    public function errmsg()
    {
        return $this->errmsg;
    }

    /* ── 内部请求 ── */
    private function request($method, $key, $body = null, $headers = [], $query = [])
    {
        $host = $this->usePathStyle
            ? parse_url($this->endpoint, PHP_URL_HOST)
            : $this->bucket . '.' . parse_url($this->endpoint, PHP_URL_HOST);

        $uri = '/' . ($this->usePathStyle ? $this->bucket . '/' : '') . $key;
        if ($query) $uri .= '?' . http_build_query($query);

        $url = ($this->isSecure() ? 'https' : 'http') . '://' . $host . $uri;

        $headers['Host'] = $host;
        if ($body !== null) {
            $headers['Content-Length'] = strlen($body);
        }

        // S3 Signature V4
        $service  = 's3';
        $algo     = 'AWS4-HMAC-SHA256';
        $now      = time();
        $dateStr  = gmdate('Ymd', $now);
        $timeStr  = gmdate('Ymd\THis\Z', $now);
        $scope    = "$dateStr/$this->region/$service/aws4_request";
        $bodyHash = $body !== null ? hash('sha256', $body) : 'UNSIGNED-PAYLOAD';

        ksort($headers);
        $signedHeaders = strtolower(implode(';', array_keys($headers)));
        $canonicalHeaders = '';
        foreach ($headers as $k => $v) {
            $canonicalHeaders .= strtolower($k) . ':' . trim($v) . "\n";
        }

        $canonicalRequest = implode("\n", [$method, $uri, '', $canonicalHeaders, $signedHeaders, $bodyHash]);
        $stringToSign = implode("\n", [$algo, $timeStr, $scope, hash('sha256', $canonicalRequest)]);

        $kDate    = hash_hmac('sha256', $dateStr, 'AWS4' . $this->secretKey, true);
        $kRegion  = hash_hmac('sha256', $this->region, $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $auth = "$algo Credential={$this->accessKey}/$scope, SignedHeaders=$signedHeaders, Signature=$signature";
        $headers['Authorization'] = $auth;
        if ($body !== null) $headers['x-amz-content-sha256'] = $bodyHash;
        $headers['x-amz-date'] = $timeStr;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);

        $curlHeaders = [];
        foreach ($headers as $k => $v) {
            $curlHeaders[] = "$k: $v";
        }
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            $curlHeaders[] = 'Content-Type: application/octet-stream';
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);

        $response = curl_exec($ch);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $this->errmsg = __FUNCTION__ . ': ' . $error;
            trigger_error($this->errmsg);
            return false;
        }

        $respHeaders = substr($response, 0, $headerSize);
        $respBody    = substr($response, $headerSize);

        // 解析响应头
        $respHeaderMap = [];
        foreach (explode("\r\n", $respHeaders) as $line) {
            if (strpos($line, ':') !== false) {
                list($k, $v) = explode(':', $line, 2);
                $respHeaderMap[strtolower(trim($k))] = trim($v);
            }
        }

        return [
            'code'    => $httpCode,
            'body'    => $respBody,
            'headers' => $respHeaderMap,
        ];
    }

    private function isSecure()
    {
        return strpos($this->endpoint, 'https://') === 0;
    }

    /* ── IStorage 接口实现 ── */

    public function exists($name)
    {
        $res = $this->request('HEAD', $this->filepath . $name);
        if ($res === false) return false;
        return $res['code'] === 200;
    }

    public function get($name)
    {
        $res = $this->request('GET', $this->filepath . $name);
        if ($res === false || $res['code'] !== 200) {
            $this->errmsg = __FUNCTION__ . ': HTTP ' . $res['code'];
            return false;
        }
        return $res['body'];
    }

    public function downfile($name, $range = false)
    {
        $headers = [];
        if ($range) {
            $headers['Range'] = 'bytes=' . $range[0] . '-' . $range[1];
        }
        $res = $this->request('GET', $this->filepath . $name, null, $headers);
        if ($res === false) return false;
        if ($res['code'] !== 200 && $res['code'] !== 206) {
            $this->errmsg = __FUNCTION__ . ': HTTP ' . $res['code'];
            return false;
        }
        echo $res['body'];
        return true;
    }

    public function upload($name, $tmpfile, $content_type = null)
    {
        $body = file_get_contents($tmpfile);
        if ($body === false) {
            $this->errmsg = __FUNCTION__ . ': 无法读取文件';
            return false;
        }
        $res = $this->request('PUT', $this->filepath . $name, $body);
        if ($res === false) return false;
        if ($res['code'] !== 200) {
            $this->errmsg = __FUNCTION__ . ': HTTP ' . $res['code'] . ' - ' . substr($res['body'], 0, 200);
            return false;
        }
        return true;
    }

    public function savefile($name, $tmpfile, $content_type = null)
    {
        return $this->upload($name, $tmpfile, $content_type);
    }

    public function getinfo($name)
    {
        $res = $this->request('HEAD', $this->filepath . $name);
        if ($res === false || $res['code'] !== 200) return false;
        return [
            'length'       => isset($res['headers']['content-length']) ? (int)$res['headers']['content-length'] : 0,
            'content_type' => isset($res['headers']['content-type']) ? $res['headers']['content-type'] : 'application/octet-stream',
        ];
    }

    public function delete($name)
    {
        $res = $this->request('DELETE', $this->filepath . $name);
        if ($res === false) return false;
        return $res['code'] === 204 || $res['code'] === 200;
    }

    public function getUploadParam($name, $filename, $max_file_size = 0)
    {
        $host = $this->usePathStyle
            ? parse_url($this->endpoint, PHP_URL_HOST)
            : $this->bucket . '.' . parse_url($this->endpoint, PHP_URL_HOST);

        $url = ($this->isSecure() ? 'https' : 'http') . '://' . $host . '/';
        $key = $this->filepath . $name;
        $expire = 3600;
        $timeStr = gmdate('Ymd\THis\Z', time() + $expire);

        // S3 POST Policy
        $conditions = [
            ['bucket' => $this->bucket],
            ['eq', '$key', $key],
            ['starts-with', '$x-amz-date', ''],
            ['starts-with', '$x-amz-algorithm', ''],
            ['starts-with', '$x-amz-credential', ''],
        ];
        if ($max_file_size > 0) {
            $conditions[] = ['content-length-range', 1, $max_file_size];
        }

        $policy = base64_encode(json_encode([
            'expiration' => $timeStr,
            'conditions' => $conditions,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

        $dateStr = gmdate('Ymd', time());
        $credential = $this->accessKey . '/' . $dateStr . '/' . $this->region . '/s3/aws4_request';

        $kDate    = hash_hmac('sha256', $dateStr, 'AWS4' . $this->secretKey, true);
        $kRegion  = hash_hmac('sha256', $this->region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $policy, $kSigning);

        $param = [
            'key'               => $key,
            'policy'            => $policy,
            'x-amz-algorithm'   => 'AWS4-HMAC-SHA256',
            'x-amz-credential'  => $credential,
            'x-amz-date'        => gmdate('Ymd\THis\Z', time()),
            'x-amz-signature'   => $signature,
            'success_action_status' => '200',
            'Cache-Control'     => 'max-age=2592000',
            'Content-Disposition' => 'attachment; filename=' . $filename,
        ];

        return ['url' => $url, 'post' => $param];
    }

    public function getDownUrl($name, $filename, $content_type = null)
    {
        global $conf;
        $key = $this->filepath . $name;
        $timeout = 315360000;

        $host = $this->usePathStyle
            ? parse_url($this->endpoint, PHP_URL_HOST) . '/' . $this->bucket
            : $this->bucket . '.' . parse_url($this->endpoint, PHP_URL_HOST);

        $uri = '/' . $key;
        $method = 'GET';
        $now = time();
        $dateStr = gmdate('Ymd', $now + $timeout);
        $timeStr = gmdate('Ymd\THis\Z', $now + $timeout);
        $scope = "$dateStr/$this->region/s3/aws4_request";

        $queryParams = [
            'X-Amz-Algorithm'  => 'AWS4-HMAC-SHA256',
            'X-Amz-Credential' => $this->accessKey . '/' . $scope,
            'X-Amz-Date'       => $timeStr,
            'X-Amz-Expires'    => $timeout,
            'X-Amz-SignedHeaders' => 'host',
        ];

        $encodedFilename = '"' . $filename . '"; filename*=utf-8\'\'' . rawurlencode($filename);
        if (!$content_type) {
            $queryParams['response-content-disposition'] = 'attachment; filename=' . $encodedFilename;
        } else {
            $queryParams['response-content-disposition'] = 'inline; filename=' . $encodedFilename;
        }

        ksort($queryParams);
        $canonicalQuery = http_build_query($queryParams);

        $canonicalRequest = implode("\n", [
            $method, $uri, $canonicalQuery,
            "host:$host\n", 'host',
            'UNSIGNED-PAYLOAD',
        ]);

        $stringToSign = implode("\n", [
            'AWS4-HMAC-SHA256', $timeStr, $scope,
            hash('sha256', $canonicalRequest),
        ]);

        $kDate    = hash_hmac('sha256', $dateStr, 'AWS4' . $this->secretKey, true);
        $kRegion  = hash_hmac('sha256', $this->region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $url = ($this->isSecure() ? 'https' : 'http') . '://' . $host . $uri . '?' . $canonicalQuery . '&X-Amz-Signature=' . $signature;

        if (!empty($conf['downfile_domain'])) {
            $url_arr = parse_url($url);
            $url = str_replace(
                $url_arr['scheme'] . '://' . $url_arr['host'],
                ($conf['downfile_protocol'] == 1 ? 'https://' : 'http://') . $conf['downfile_domain'],
                $url
            );
        }

        return $url;
    }
}
