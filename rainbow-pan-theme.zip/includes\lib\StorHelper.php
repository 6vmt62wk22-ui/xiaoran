<?php
/**
 * 存储工厂类 (新增 S3 支持)
 */
namespace lib;

class StorHelper
{
    private static function getConfig($storage)
    {
        global $conf;
        switch ($storage) {
            case 'local':
                return $conf['filepath'];
            case 'sae':
                return $conf['storagename'];
            case 'ace':
                return $conf['storagename'];
            case 'oss':
                return [
                    'accessKeyId'     => $conf['oss_ak'],
                    'accessKeySecret' => $conf['oss_sk'],
                    'endpoint'        => $conf['oss_endpoint'],
                    'bucket'          => $conf['oss_bucket'],
                ];
            case 'qcloud':
                return [
                    'secretId'  => $conf['qcloud_id'],
                    'secretKey' => $conf['qcloud_key'],
                    'region'    => $conf['qcloud_region'],
                    'bucket'    => $conf['qcloud_bucket'],
                ];
            case 'obs':
                return [
                    'accessKey' => $conf['obs_ak'],
                    'secretKey' => $conf['obs_sk'],
                    'endpoint'  => $conf['obs_endpoint'],
                    'bucket'    => $conf['obs_bucket'],
                ];
            case 'upyun':
                return [
                    'operatorName' => $conf['upyun_user'],
                    'operatorPwd'  => $conf['upyun_pwd'],
                    'serviceName'  => $conf['upyun_name'],
                ];
            case 'qiniu':
                return [
                    'accessKey' => $conf['qiniu_ak'],
                    'secretKey' => $conf['qiniu_sk'],
                    'bucket'    => $conf['qiniu_bucket'],
                    'domain'    => $conf['qiniu_domain'],
                ];
            case 's3':
                return [
                    'accessKey' => $conf['s3_ak'],
                    'secretKey' => $conf['s3_sk'],
                    'region'    => $conf['s3_region'],
                    'endpoint'  => $conf['s3_endpoint'],
                    'bucket'    => $conf['s3_bucket'],
                ];
            default:
                return null;
        }
    }

    public static function getModel($storage)
    {
        $classMap = [
            's3'     => 'S3',
            'oss'    => 'Oss',
            'qcloud' => 'Qcloud',
            'obs'    => 'Obs',
            'qiniu'  => 'Qiniu',
            'upyun'  => 'Upyun',
            'local'  => 'Local',
            'sae'    => 'Sae',
            'ace'    => 'Ace',
        ];

        $className = isset($classMap[$storage]) ? $classMap[$storage] : ucwords($storage);
        $class = "\\lib\\Storage\\" . $className;
        $config = self::getConfig($storage);

        if (class_exists($class)) {
            return new $class($config);
        }
        return false;
    }

    public static function is_cloud()
    {
        global $conf;
        return in_array($conf['storage'], ['oss', 'qcloud', 'obs', 'upyun', 'qiniu', 's3']);
    }

    public static function is_range()
    {
        global $conf;
        return in_array($conf['storage'], ['local', 'oss', 'qcloud', 'obs', 'qiniu', 's3']);
    }
}
