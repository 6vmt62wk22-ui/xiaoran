<?php
/**
 * 管理员登录 — XIAORAN极简版
 */
$verifycode = 1;
if(!function_exists("imagecreate") || !file_exists('code.php')) $verifycode = 0;

define('IN_ADMIN', true);
include("../includes/common.php");

if(isset($_POST['user']) && isset($_POST['pass'])) {
    if(!$_SESSION['pass_error']) $_SESSION['pass_error'] = 0;

    $user = daddslashes($_POST['user']);
    $pass = daddslashes($_POST['pass']);
    $code = daddslashes($_POST['code']);

    if($verifycode == 1 && (!$code || strtolower($code) != $_SESSION['vc_code'])) {
        unset($_SESSION['vc_code']);
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script>alert('验证码错误！');history.go(-1);</script>");
    } elseif($_SESSION['pass_error'] > 5) {
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script>alert('登录失败次数过多，请稍后再试！');history.go(-1);</script>");
    } elseif($user == $conf['admin_user'] && $pass == $conf['admin_pwd']) {
        $_SESSION['pass_error'] = 0;
        $session = md5($user . $pass . $password_hash);
        $expiretime = time() + 2592000;
        $token = authcode("{$user}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
        ob_clean();
        setcookie("admin_token", $token, time() + 2592000, '/', '', false, true);
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script>window.location.href='./';</script>");
    } else {
        $_SESSION['pass_error']++;
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script>alert('用户名或密码不正确！');history.go(-1);</script>");
    }
} elseif(isset($_GET['logout'])) {
    setcookie("admin_token", "", time() - 2592000, '/');
    @header('Content-Type: text/html; charset=UTF-8');
    exit("<script>alert('您已成功注销！');window.location.href='./login.php';</script>");
} elseif($islogin == 1) {
    exit("<script>window.location.href='./';</script>");
}
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="renderer" content="webkit">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>管理员登录 - <?php echo $conf['title']; ?></title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"PingFang SC","Microsoft YaHei",sans-serif;
    background:#f5f6fa;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:20px;
}
.login-wrap{
    width:100%;
    max-width:400px;
}
.login-header{
    text-align:center;
    margin-bottom:32px;
}
.login-header h1{
    font-size:24px;
    font-weight:700;
    color:#2c3e50;
    margin-bottom:6px;
}
.login-header p{
    font-size:13px;
    color:#95a5a6;
}
.login-card{
    background:#fff;
    border-radius:12px;
    padding:36px 32px;
    box-shadow:0 2px 16px rgba(0,0,0,.06);
    border:1px solid #eef0f5;
}
.form-group{
    margin-bottom:20px;
    position:relative;
}
.form-group label{
    display:block;
    font-size:12px;
    font-weight:600;
    color:#7f8c8d;
    margin-bottom:6px;
    letter-spacing:.5px;
    text-transform:uppercase;
}
.form-group input{
    width:100%;
    height:44px;
    padding:0 14px;
    font-size:14px;
    color:#2c3e50;
    background:#f8f9fb;
    border:1.5px solid #e8ecf1;
    border-radius:8px;
    outline:none;
    transition:all .2s;
}
.form-group input:focus{
    background:#fff;
    border-color:#3498db;
    box-shadow:0 0 0 3px rgba(52,152,219,.1);
}
.form-group input::placeholder{color:#bdc3c7;font-size:13px;}

/* 验证码行 */
.code-row{
    display:flex;
    gap:10px;
}
.code-row input{flex:1;}
.code-row img{
    height:44px;
    width:110px;
    border-radius:8px;
    cursor:pointer;
    border:1px solid #e8ecf1;
    flex-shrink:0;
}

/* 登录按钮 */
.btn-login{
    width:100%;
    height:46px;
    background:#2c3e50;
    color:#fff;
    border:none;
    border-radius:8px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:all .2s;
    letter-spacing:.5px;
    margin-top:4px;
}
.btn-login:hover{
    background:#34495e;
    transform:translateY(-1px);
    box-shadow:0 4px 12px rgba(44,62,80,.25);
}
.btn-login:active{transform:translateY(0);}

/* 底部链接 */
.login-footer{
    text-align:center;
    margin-top:20px;
    font-size:12px;
    color:#bdc3c7;
}
.login-footer a{
    color:#7f8c8d;
    text-decoration:none;
}
.login-footer a:hover{color:#2c3e50;}

@media (max-width:480px){
    .login-card{padding:28px 20px;}
}
</style>
</head>
<body>
<div class="login-wrap">
    <div class="login-header">
        <h1><?php echo $conf['title']; ?></h1>
        <p>管理员登录</p>
    </div>
    <div class="login-card">
        <form method="post" autocomplete="off">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="user" required placeholder="请输入管理员用户名" autocomplete="off">
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="pass" required placeholder="请输入密码" autocomplete="off">
            </div>
            <?php if($verifycode == 1): ?>
            <div class="form-group">
                <label>验证码</label>
                <div class="code-row">
                    <input type="text" name="code" required placeholder="请输入验证码" maxlength="4" autocomplete="off">
                    <img src="code.php" onclick="this.src='code.php?'+Math.random()" title="点击刷新验证码" alt="验证码">
                </div>
            </div>
            <?php endif; ?>
            <?php if(isset($_SESSION['pass_error']) && $_SESSION['pass_error'] > 0): ?>
            <div class="form-group" style="background:#fdf2f2;padding:10px 14px;border-radius:8px;font-size:12px;color:#e74c3c;text-align:center;">
                已错误 <?php echo $_SESSION['pass_error']; ?> 次，最多 5 次
            </div>
            <?php endif; ?>
            <button type="submit" class="btn-login">登 录</button>
        </form>
    </div>
    <div class="login-footer">
        <a href="../">← 返回前台</a>
    </div>
</div>
</body>
</html>
