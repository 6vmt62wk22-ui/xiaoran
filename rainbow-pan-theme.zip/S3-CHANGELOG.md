# S3 存储集成 + 登录美化 + 后端优化 说明

> 基于彩虹外链网盘 V5.6，以 `pan.suyanw.cn` 为风格参考。

---

## 一、新增 S3 兼容存储

### 支持平台

| 平台 | Endpoint 示例 | Region |
|------|-------------|--------|
| **AWS S3** | `https://s3.amazonaws.com` | `us-east-1` |
| **Cloudflare R2** | `https://[accountid].r2.cloudflarestorage.com` | `auto` |
| **MinIO** | `http://127.0.0.1:9000` | `us-east-1` |
| **阿里云 OSS (S3兼容)** | `https://oss-cn-hangzhou.aliyuncs.com` | `oss-cn-hangzhou` |
| **腾讯云 COS (S3兼容)** | `https://cos.ap-shanghai.myqcloud.com` | `ap-shanghai` |
| **其他 S3 兼容** | 自定义 | 自定义 |

### 新增/修改文件

```
rainbow-pan-v56/
├── includes/lib/Storage/S3.php      ← 新增：S3 存储驱动 (纯 PHP 实现，无需 SDK)
├── includes/lib/StorHelper.php      ← 修改：添加 's3' 配置和路由
├── admin/set_stor.php               ← 修改：新增 S3 配置面板
└── admin/ajax.php                   ← 无需改动 (通用 saveSetting)
```

### S3 驱动特性

- **零依赖**：纯 PHP + cURL 实现，无需 Composer / AWS SDK
- **Signature V4**：完整的 AWS Signature V4 签名算法
- **Path-Style 自动检测**：R2 / MinIO 自动使用 path-style 请求
- **断点续传**：支持 HTTP Range 请求
- **直传支持**：POST Policy 签名直传
- **签名 URL**：私有 Bucket 下载链接自动签名

### 后台配置步骤

1. 后台 → 存储类型设置 → 选择 `Amazon S3 / R2 / MinIO`
2. 展开 S3 面板，填写 5 项信息：

| 字段 | 说明 |
|------|------|
| Access Key | 你的 S3 Access Key |
| Secret Key | 你的 S3 Secret Key |
| Region | AWS: `us-east-1` / R2: `auto` |
| Endpoint | 完整的 HTTPS 地址 |
| Bucket | 存储桶名称 |

3. 选择上传/下载方式（建议直链模式）
4. 保存设置

### R2 特别说明

Cloudflare R2 需要：
- Region 填 `auto`
- Endpoint 格式：`https://[你的AccountID].r2.cloudflarestorage.com`
- 在 R2 控制台 → Settings → 允许 CORS（如用直传）

### MinIO 特别说明

自建 MinIO：
- Region 填 `us-east-1`
- Endpoint 填 `http://你的服务器IP:9000`
- 确保 Bucket 设为 Public 或配置好签名访问

---

## 二、登录界面美化

### 改造内容

| 原版 | 新版 |
|------|------|
| 渐变青紫背景 | 纯白灰极简背景 |
| Bootstrap 3 表单 | 自定义现代表单 |
| 阴影盒子 | 圆角卡片 + 轻阴影 |
| 灰色输入框 | 浅灰底色 + 蓝色聚焦光环 |
| 无验证码框 | 完整验证码行 (图片+输入) |
| 无错误提示 | 红色错误次数提示条 |
| 无响应式 | 完整移动端适配 |

### 新增文件

```
admin/login.php         ← 重写：XIAORAN极简登录页
admin/login-preview.html ← 新增：登录页独立预览
```

### 安全增强

- Cookie 设置 `HttpOnly` + `Secure` + `SameSite=Lax`
- 登录成功后清除错误计数器
- Token 过期时间 30 天

---

## 三、后端安全优化

### 新增 `includes/security.php` 安全函数库

| 函数 | 作用 |
|------|------|
| `csrf_token()` / `csrf_check()` | CSRF Token 生成与校验 |
| `csrf_field()` | 表单隐藏 CSRF 字段 |
| `safe_redirect($url)` | 安全重定向 (防止 Open Redirect) |
| `rate_limit($key, $max, $window)` | 请求频率限制 |
| `security_log($event, $detail)` | 安全事件日志 |
| `is_ip_blocked($ip)` | IP 黑名单检查 (支持 CIDR) |
| `sanitize_filename($name)` | 文件名安全过滤 (防路径穿越) |
| `sanitize_int($val, $default)` | 整数安全过滤 |
| `send_security_headers()` | 安全响应头 (X-Content-Type-Options 等) |
| `secure_session_start()` | Session 安全启动 (防固定攻击) |

### 引入方式

在 `includes/common.php` 末尾添加：

```php
include(ROOT . 'includes/security.php');
secure_session_start();
send_security_headers();
```

---

## 四、部署清单

### 新增文件（直接上传覆盖）

| 文件 | 目标路径 |
|------|---------|
| `includes/lib/Storage/S3.php` | `网站根目录/includes/lib/Storage/S3.php` |
| `includes/lib/StorHelper.php` | `网站根目录/includes/lib/StorHelper.php` ← 覆盖 |
| `includes/security.php` | `网站根目录/includes/security.php` |
| `admin/set_stor.php` | `网站根目录/admin/set_stor.php` ← 覆盖 |
| `admin/login.php` | `网站根目录/admin/login.php` ← 覆盖 |

### 可选：common.php 添加安全头

编辑 `includes/common.php`，在文件末尾 `?>` 前添加：

```php
include(ROOT . 'includes/security.php');
secure_session_start();
send_security_headers();
```

### 部署完成后

1. 浏览器强制刷新 (`Ctrl+Shift+R`)
2. 访问 `/admin/login.php` 查看新登录页
3. 登录后台 → 存储类型设置 → 选择 S3 并配置
4. 测试上传一个文件验证 S3 存储
