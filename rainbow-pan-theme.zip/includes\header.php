<?php
/**
 * 彩虹外链网盘 V5.6 — XIAORAN风格 header.php
 * 直接替换 includes/header.php
 * 保留全部原始 PHP 逻辑，新增通知栏、主题切换
 */
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo isset($navtitle) ? $navtitle.' - ' : ''; ?><?php echo $conf['title']?></title>
  <meta name="keywords" content="<?php echo $conf['keywords']?>">
  <meta name="description" content="<?php echo $conf['description']?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="format-detection" content="telephone=no">
  <!-- Font Awesome -->
  <link href="https://s4.zstatic.net/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <!-- Bootstrap 3 -->
  <link href="https://s4.zstatic.net/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
  <!-- XIAORAN美化版样式 -->
  <link href="assets/css/style.css?v=<?php echo time();?>" rel="stylesheet">
  <!--[if lt IE 9]>
    <script src="https://s4.zstatic.net/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://s4.zstatic.net/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://s4.zstatic.net/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <?php
  if(isset($fileview) && $fileview){
    echo '<link rel="stylesheet" href="https://s4.zstatic.net/ajax/libs/aplayer/1.10.1/APlayer.min.css">';
    echo '<link href="assets/css/ckplayer.css" rel="stylesheet">';
  }
  ?>
</head>
<body>

  <!-- 顶部通知横幅轮播 -->
  <div class="top-notice-bar" id="noticeBar">
    <div class="notice-carousel">
      <button class="carousel-prev" title="上一条">&lsaquo;</button>
      <div class="notice-item active">
        <b>请勿上传违法、违规或敏感内容</b>，单文件最大 <b>300MB</b>。
      </div>
      <div class="notice-item">
        本站使用阿里云 <b>CDN 加速</b>，确保访问快速稳定。
      </div>
      <div class="notice-item">
        广告投放与合作请联系邮箱：<b><?php echo isset($conf['email']) ? $conf['email'] : 'admin@example.com'; ?></b>
      </div>
      <button class="carousel-next" title="下一条">&rsaquo;</button>
    </div>
    <button class="notice-close" id="noticeClose" title="关闭通知">&times;</button>
  </div>

  <!-- 广告轮播区 -->
  <div class="container" style="margin-top:12px;">
    <div class="ad-carousel" id="adCarousel">
      <div class="ad-slide active">
        <a href="#" target="_blank">
          <div style="height:100px;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#999;font-size:14px;">
            广告位招租
          </div>
        </a>
      </div>
      <div class="ad-slide">
        <a href="#" target="_blank">
          <div style="height:100px;background:#eaf4fd;display:flex;align-items:center;justify-content:center;color:#666;font-size:14px;">
            广告位招租 — 联系管理员
          </div>
        </a>
      </div>
      <div class="ad-dots">
        <button class="ad-dot active"></button>
        <button class="ad-dot"></button>
      </div>
    </div>
  </div>

  <nav class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./"><?php echo $conf['title']?></a>
      </div>
      <div class="navbar-collapse collapse navbar-responsive-collapse">
        <ul class="nav navbar-nav">
          <li class="<?php echo (isset($navid) && $navid==0)?'active':''; ?>"><a href="./"><i class="fa fa-list"></i> 文件列表</a></li>
          <li class="<?php echo (isset($navid) && $navid==1)?'active':''; ?>"><a href="./upload.php"><i class="fa fa-cloud-upload"></i> 上传文件</a></li>
          <?php if(isset($navid) && $navid==2){ ?>
          <li class="active"><a href=""><i class="fa fa-file"></i> 文件查看</a></li>
          <?php } ?>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <!-- 主题切换 -->
          <li class="theme-switcher" id="themeSwitcher">
            <a href="#" class="theme-current" id="themeToggle">
              <span class="theme-dot"></span> 主题 <b class="caret"></b>
            </a>
            <div class="theme-dropdown" id="themeDropdown">
              <button class="theme-option active" data-theme="default"><span class="dot" style="background:#4a4a4a;"></span> 默认</button>
              <button class="theme-option" data-theme="amethyst"><span class="dot" style="background:#9b59b6;"></span> 紫水晶</button>
              <button class="theme-option" data-theme="city"><span class="dot" style="background:#34495e;"></span> 城市</button>
              <button class="theme-option" data-theme="flat"><span class="dot" style="background:#1abc9c;"></span> 扁平</button>
              <button class="theme-option" data-theme="modern"><span class="dot" style="background:#e74c3c;"></span> 现代</button>
              <button class="theme-option" data-theme="smooth"><span class="dot" style="background:#3498db;"></span> 流畅</button>
            </div>
          </li>
          <li class="<?php echo (isset($navid) && $navid==3)?'active':''; ?>"><a href="./?m=mine"><i class="fa fa-folder-open"></i> 我的文件</a></li>
          <?php if(!empty($islogin) && $islogin){ ?>
          <li><a href="./user.php"><i class="fa fa-user"></i> <?php echo $user?></a></li>
          <li><a href="./login.php?act=logout"><i class="fa fa-sign-out"></i> 退出</a></li>
          <?php }else{ ?>
          <li class="<?php echo (isset($navid) && $navid==4)?'active':''; ?>"><a href="./login.php"><i class="fa fa-user-circle"></i> 登录</a></li>
          <?php } ?>
        </ul>
      </div>
    </div>
  </nav>
