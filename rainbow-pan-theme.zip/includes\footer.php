<?php
/**
 * 彩虹外链网盘 V5.6 — XIAORAN风格 footer.php
 * 直接替换 includes/footer.php
 * 新增友情链接、安全计时器、广告区、看板娘
 */
?>
    <footer class="footer text-center">
      <div class="container">
        <!-- 友情链接 -->
        <div class="friend-links">
          <a href="/sponsor">赞助打赏</a>
          <a href="#">友情链接2</a>
          <a href="#">友情链接3</a>
          <a href="#">友情链接4</a>
          <a href="#">友情链接5</a>
          <a href="#">友情链接6</a>
        </div>
        <!-- 安全运行计时 -->
        <div class="runtime-counter" id="runtimeCounter">
          本站已不间断安全运行 <span id="runDays">0</span> 天 <span id="runHours">0</span> 时 <span id="runMins">0</span> 分 <span id="runSecs">0</span> 秒
        </div>
        <p class="text-muted">
          Copyright &copy; <?php echo date('Y')?> <a href="/"><?php echo $conf['title']?></a>
          <?php echo $conf['tongji']?>
        </p>
      </div>

      <!-- 底部广告区 -->
      <div class="ad-grid">
        <a href="#">广告位招租</a><a href="#">广告位招租</a><a href="#">广告位招租</a>
        <a href="#">广告位招租</a><a href="#">广告位招租</a><a href="#">广告位招租</a>
        <a href="#">广告位招租</a><a href="#">广告位招租</a><a href="#">广告位招租</a>
        <a href="#">广告位招租</a><a href="#">广告位招租</a><a href="#">广告位招租</a>
      </div>
    </footer>

    <!-- 看板娘 -->
    <div class="kanban-musume" id="kanbanMusume">
      <button class="kanban-close" id="kanbanClose">&times;</button>
      <img src="assets/img/kanban.png" alt="看板娘" onerror="this.style.display='none';this.parentElement.style.display='none';">
    </div>

    <!-- ========== JS 脚本 ========== -->
    <script src="https://s4.zstatic.net/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
    (function(){
      /* ── 通知横幅轮播 ── */
      var noticeItems = document.querySelectorAll('#noticeBar .notice-item');
      var noticeIdx = 0;
      var noticeTimer;
      function noticeGo(n) {
        noticeItems[noticeIdx].classList.remove('active');
        noticeIdx = (n + noticeItems.length) % noticeItems.length;
        noticeItems[noticeIdx].classList.add('active');
      }
      function noticeNext() { noticeGo(noticeIdx + 1); }
      function noticePrev() { noticeGo(noticeIdx - 1); }
      function noticeAuto() { noticeTimer = setInterval(noticeNext, 4000); }

      var prevBtn = document.querySelector('#noticeBar .carousel-prev');
      var nextBtn = document.querySelector('#noticeBar .carousel-next');
      if(prevBtn) prevBtn.addEventListener('click', function(e){ e.preventDefault(); clearInterval(noticeTimer); noticePrev(); noticeAuto(); });
      if(nextBtn) nextBtn.addEventListener('click', function(e){ e.preventDefault(); clearInterval(noticeTimer); noticeNext(); noticeAuto(); });
      var closeBtn = document.getElementById('noticeClose');
      if(closeBtn) closeBtn.addEventListener('click', function(){ var bar = document.getElementById('noticeBar'); if(bar) bar.style.display = 'none'; clearInterval(noticeTimer); });
      noticeAuto();

      /* ── 广告轮播 ── */
      var adSlides = document.querySelectorAll('#adCarousel .ad-slide');
      var adDots = document.querySelectorAll('#adCarousel .ad-dot');
      if(adSlides.length && adDots.length) {
        var adIdx = 0;
        var adTimer;
        function adGo(n) {
          adSlides[adIdx].classList.remove('active');
          adDots[adIdx].classList.remove('active');
          adIdx = n % adSlides.length;
          adSlides[adIdx].classList.add('active');
          adDots[adIdx].classList.add('active');
        }
        adDots.forEach(function(dot, i){ dot.addEventListener('click', function(){ clearInterval(adTimer); adGo(i); adTimer = setInterval(function(){ adGo(adIdx + 1); }, 5000); }); });
        adTimer = setInterval(function(){ adGo(adIdx + 1); }, 5000);
      }

      /* ── 安全运行计时器 ── */
      (function(){
        // 使用 PHP 输出站点创建日期，默认 2026-01-01
        var startDate = "<?php echo isset($conf['startdate']) ? $conf['startdate'] : '2026-01-01'; ?>";
        var start = new Date(startDate).getTime();
        function tick() {
          var diff = Math.floor((Date.now() - start) / 1000);
          var d = Math.floor(diff / 86400);
          var h = Math.floor((diff % 86400) / 3600);
          var m = Math.floor((diff % 3600) / 60);
          var s = diff % 60;
          var rd = document.getElementById('runDays'), rh = document.getElementById('runHours');
          var rm = document.getElementById('runMins'), rs = document.getElementById('runSecs');
          if(rd) rd.textContent = d;
          if(rh) rh.textContent = h;
          if(rm) rm.textContent = m;
          if(rs) rs.textContent = s;
        }
        tick();
        setInterval(tick, 1000);
      })();

      /* ── 看板娘 ── */
      var kanbanClose = document.getElementById('kanbanClose');
      if(kanbanClose) {
        kanbanClose.addEventListener('click', function(){
          var km = document.getElementById('kanbanMusume');
          if(km) km.classList.add('hidden');
          document.cookie = 'kanban_hidden=1;max-age=86400;path=/';
        });
        if (document.cookie.indexOf('kanban_hidden=1') !== -1) {
          var km = document.getElementById('kanbanMusume');
          if(km) km.classList.add('hidden');
        }
      }

      /* ── 主题切换 ── */
      (function(){
        var savedTheme = localStorage.getItem('pan-theme') || 'default';
        if(savedTheme !== 'default') document.documentElement.setAttribute('data-theme', savedTheme);
        updateUI(savedTheme);

        var toggle = document.getElementById('themeToggle');
        var switcher = document.getElementById('themeSwitcher');
        if(toggle && switcher) {
          toggle.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); switcher.classList.toggle('open'); });
        }
        document.addEventListener('click', function(e){
          if(switcher && !e.target.closest('#themeSwitcher')) switcher.classList.remove('open');
        });
        document.querySelectorAll('.theme-option').forEach(function(btn){
          btn.addEventListener('click', function(){
            var theme = this.getAttribute('data-theme');
            document.documentElement.setAttribute('data-theme', theme === 'default' ? '' : theme);
            localStorage.setItem('pan-theme', theme);
            updateUI(theme);
            if(switcher) switcher.classList.remove('open');
          });
        });
        function updateUI(theme) {
          document.querySelectorAll('.theme-option').forEach(function(o){ o.classList.remove('active'); });
          var active = document.querySelector('.theme-option[data-theme="'+theme+'"]');
          if(active) active.classList.add('active');
        }
      })();

      /* ── 搜索框自动聚焦 ── */
      var si = document.querySelector('.searchbox input');
      if(si){ si.setAttribute('placeholder','搜索文件名...'); }

      /* ── 表格行点击 ── */
      document.querySelectorAll('.filelist tbody tr').forEach(function(tr){
        tr.style.cursor = 'pointer';
        tr.addEventListener('click', function(e){
          if(e.target.tagName === 'A' || e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON') return;
          var link = tr.querySelector('a');
          if(link) window.location.href = link.href;
        });
      });

      /* ── 操作链接图标 ── */
      document.querySelectorAll('.filelist a').forEach(function(a){
        var t = a.textContent.trim();
        if(t === '下载') a.innerHTML = '<i class="fa fa-download"></i> '+t;
        if(t === '查看') a.innerHTML = '<i class="fa fa-eye"></i> '+t;
      });
    })();
    </script>

    <?php if(isset($GLOBALS['loadlayer'])){ ?>
    <script src="https://s4.zstatic.net/ajax/libs/layer/2.3/layer.js"></script>
    <?php } ?>
</body>
</html>
