# 彩虹外链网盘 V5.6 — XIAORAN美化版 部署教程

> 适用版本：彩虹外链网盘 V5.6（github.com/netcccyun/pan）
> 美化风格：极简黑白灰 · 6 主题 · S3 存储 · 安全优化

---

## 文件清单

```
rainbow-pan-v56/
├── assets/css/style.css              ← 核心样式（6主题 + 弹窗）
├── includes/
│   ├── header.php                     ← 导航栏（通知轮播 + 主题切换）
│   ├── footer.php                     ← 页脚（友链 + 计时器 + 看板娘）
│   ├── security.php                   ← 新增：10 项安全函数库
│   └── lib/
│       ├── Storage/S3.php             ← 新增：S3 存储驱动
│       └── StorHelper.php             ← S3 存储类型路由
├── admin/
│   ├── login.php                      ← XIAORAN极简登录页
│   └── set_stor.php                   ← S3 配置面板
├── INSTALL.md                         ← 详细说明
└── S3-CHANGELOG.md                    ← S3 集成文档
```

---

## 方式一：宝塔面板（推荐）

1. 上传 `rainbow-pan-theme.zip` 到服务器
2. 宝塔 → 文件 → 进入网站根目录（`/www/wwwroot/你的域名`）
3. 右键 zip → 解压 → 全部覆盖
4. 浏览器 `Ctrl + Shift + R` 强制刷新

---

## 方式二：SSH 命令行

```bash
# 1. 上传 zip 到服务器
scp rainbow-pan-theme.zip root@你的IP:/tmp/

# 2. SSH 登录，进入网站根目录
cd /www/wwwroot/你的域名

# 3. 备份原文件（强烈建议）
mkdir -p bak/$(date +%Y%m%d)
cp assets/css/style.css bak/$(date +%Y%m%d)/ 2>/dev/null
cp includes/header.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp includes/footer.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp includes/lib/StorHelper.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp admin/login.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp admin/set_stor.php bak/$(date +%Y%m%d)/ 2>/dev/null

# 4. 解压覆盖
unzip -o /tmp/rainbow-pan-theme.zip -d .

# 5. 重启 Nginx
/etc/init.d/nginx reload
```

---

## 可选：激活安全函数

编辑 `includes/common.php`，在 `?>` 前添加 3 行：

```php
include(ROOT . 'includes/security.php');
secure_session_start();
send_security_headers();
```

提供 CSRF 防护 / 频率限制 / 安全重定向 / IP 黑名单 / 文件名过滤 / 安全头 等 10 项防护。

---

## S3 配置速查表

后台 → 存储类型 → 选择 `Amazon S3 / R2 / MinIO`，填写：

| 平台 | Region | Endpoint |
|------|--------|----------|
| AWS S3 | `us-east-1` | `https://s3.amazonaws.com` |
| Cloudflare R2 | `auto` | `https://[accountid].r2.cloudflarestorage.com` |
| MinIO | `us-east-1` | `http://127.0.0.1:9000` |
| 腾讯云 COS | `ap-shanghai` | `https://cos.ap-shanghai.myqcloud.com` |
| 阿里云 OSS | `oss-cn-hangzhou` | `https://oss-cn-hangzhou.aliyuncs.com` |

---

## Nginx 配置

```nginx
# 伪静态（V5.6 必须）
if (!-e $request_filename) {
    rewrite ^/(.*)$ /index.php?$1 last;
}

# 静态资源缓存
location ~* \.(css|js|jpg|png|gif|ico|svg|woff2?)$ {
    expires 30d;
    add_header Cache-Control "public, immutable";
}

# 禁止访问敏感文件
location ~* \.(sql|log|zip|tar|gz|bak)$ {
    deny all;
}
```

---

## PHP 环境

```
PHP >= 7.0（推荐 7.4 / 8.0）
```

必需扩展：`fileinfo` `curl` `json` `mbstring` `openssl`

```ini
upload_max_filesize = 200M
post_max_size = 220M
max_execution_time = 300
```

---

## 功能一览

| 分类 | 功能 |
|------|------|
| 视觉 | 极简黑白灰 / 6 主题切换 / 通知轮播 / 广告轮播 / 看板娘 / 安全计时器 / 友链 |
| 弹窗 | 文件详情 / 分享链接 / 二维码 / 删除确认 / Toast 通知 |
| 存储 | AWS S3 / R2 / MinIO / 腾讯云 COS / 阿里云 OSS |
| 安全 | CSRF / 频率限制 / 安全重定向 / IP 黑名单 / 文件名过滤 / Session 安全 |
| 响应式 | 桌面 / 平板 / 手机 全适配 |

---

## 主题配色

| 主题 | 强调色 | 特点 |
|------|--------|------|
| 默认 | `#4a4a4a` | 中性灰黑 |
| 紫水晶 | `#9b59b6` | 优雅紫色 |
| 城市 | `#34495e` | 沉稳商务 |
| 扁平 | `#1abc9c` | 青绿无圆角 |
| 现代 | `#e74c3c` | 热情红色 |
| 柔和 | `#3498db` | 清爽蓝色 |

---

## 常见问题

**覆盖后样式没变化？**
- 浏览器 `Ctrl+Shift+R` 强制刷新
- CDN 用户需刷新 CDN 缓存
- 确认文件权限为 `644`

**如何还原？**
```bash
cp bak/日期/style.css assets/css/style.css
cp bak/日期/header.php includes/header.php
cp bak/日期/footer.php includes/footer.php
cp bak/日期/StorHelper.php includes/lib/StorHelper.php
cp bak/日期/login.php admin/login.php
cp bak/日期/set_stor.php admin/set_stor.php
```

或从 GitHub 重新下载 V5.6 原版：https://github.com/netcccyun/pan

---

美化 & 优化 by WorkBuddy · 2026
