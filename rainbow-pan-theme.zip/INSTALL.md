# 彩虹外链网盘 V5.6 美化版

> XIAORAN极简风格 · S3 存储集成 · 安全优化 · 6 套主题切换

适用版本：彩虹外链网盘 V5.6（https://github.com/netcccyun/pan）

---

## 文件清单

```
rainbow-pan-v56/
├── assets/
│   └── css/
│       └── style.css                  ← 替换：核心样式（6主题 + 弹窗）
├── includes/
│   ├── header.php                     ← 替换：导航栏（通知轮播 + 主题切换）
│   ├── footer.php                     ← 替换：页脚（友链 + 计时器 + 看板娘）
│   ├── security.php                   ← 新增：10 项安全函数库
│   └── lib/
│       ├── Storage/
│       │   └── S3.php                 ← 新增：S3 存储驱动（零依赖）
│       └── StorHelper.php             ← 替换：S3 存储类型路由
├── admin/
│   ├── login.php                      ← 替换：XIAORAN极简登录页
│   ├── login-preview.html             ← 预览（无需上传）
│   └── set_stor.php                   ← 替换：S3 配置面板
├── preview.html                       ← 预览（无需上传）
├── INSTALL.md                         ← 本说明
└── S3-CHANGELOG.md                    ← S3 集成文档
```

---

## 部署方式

### 方式一：宝塔面板（推荐）

1. 上传 `rainbow-pan-theme.zip` 到服务器
2. 宝塔 → 文件 → 进入网站根目录（如 `/www/wwwroot/你的域名`）
3. 右键 zip → 解压 → 全部覆盖

或逐个替换：

| 文件 | 目标路径 |
|------|---------|
| `style.css` | `网站根目录/assets/css/style.css` |
| `header.php` | `网站根目录/includes/header.php` |
| `footer.php` | `网站根目录/includes/footer.php` |
| `security.php` | `网站根目录/includes/security.php` |
| `S3.php` | `网站根目录/includes/lib/Storage/S3.php` |
| `StorHelper.php` | `网站根目录/includes/lib/StorHelper.php` |
| `login.php` | `网站根目录/admin/login.php` |
| `set_stor.php` | `网站根目录/admin/set_stor.php` |

### 方式二：SSH 命令行

```bash
# 1. 上传 zip 到服务器
scp rainbow-pan-theme.zip root@你的IP:/tmp/

# 2. SSH 登录，进入网站根目录
cd /www/wwwroot/你的域名

# 3. 备份原文件（可选）
mkdir -p bak/$(date +%Y%m%d)
cp assets/css/style.css bak/$(date +%Y%m%d)/ 2>/dev/null
cp includes/header.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp includes/footer.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp includes/lib/StorHelper.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp admin/login.php bak/$(date +%Y%m%d)/ 2>/dev/null
cp admin/set_stor.php bak/$(date +%Y%m%d)/ 2>/dev/null

# 4. 解压覆盖
unzip -o /tmp/rainbow-pan-theme.zip -d .

# 5. 重启服务
/etc/init.d/nginx reload
```

### 可选：激活安全函数

编辑 `includes/common.php`，在 `?>` 前添加：

```php
include(ROOT . 'includes/security.php');
secure_session_start();
send_security_headers();
```

### 部署后验证

1. 浏览器 **强制刷新**（`Ctrl+Shift+R`，关键！）
2. 确认导航栏通知轮播 + 主题切换正常
3. 访问 `/admin/login.php` 检查新登录页
4. 后台 → 存储类型设置 → 选择 S3 并配置

---

## S3 配置步骤

1. 后台 → 存储类型 → 选择 `Amazon S3 / R2 / MinIO`
2. 展开 S3 面板，填写 5 项：

| 字段 | 说明 | 示例 |
|------|------|------|
| Access Key | S3 访问密钥 | `AKIAIOSFODNN7EXAMPLE` |
| Secret Key | S3 密钥 | `wJalrXUtnFEMI/K7MDENG...` |
| Region | 区域 | AWS: `us-east-1` / R2: `auto` |
| Endpoint | 服务端地址 | `https://s3.amazonaws.com` |
| Bucket | 存储桶名 | `my-bucket` |

**各平台示例**：

| 平台 | Region | Endpoint |
|------|--------|----------|
| AWS S3 | `us-east-1` | `https://s3.amazonaws.com` |
| Cloudflare R2 | `auto` | `https://[accountid].r2.cloudflarestorage.com` |
| MinIO | `us-east-1` | `http://127.0.0.1:9000` |
| 腾讯云 COS | `ap-shanghai` | `https://cos.ap-shanghai.myqcloud.com` |
| 阿里云 OSS | `oss-cn-hangzhou` | `https://oss-cn-hangzhou.aliyuncs.com` |

---

## Nginx 配置

```nginx
# 伪静态（V5.6 必须）
if (!-e $request_filename) {
    rewrite ^/(.*)$ /index.php?$1 last;
}

# 静态资源缓存
location ~* \.(css|js|jpg|png|gif|ico|svg|woff2?)$ {
    expires 30d;
    add_header Cache-Control "public, immutable";
}

# 禁止访问敏感文件
location ~* \.(sql|log|zip|tar|gz|bak)$ {
    deny all;
}
```

---

## PHP 环境

```
PHP >= 7.0（推荐 7.4 / 8.0）
```

必需扩展：
- `fileinfo` — 文件类型检测
- `curl` — API 请求 / S3 签名
- `json` — 数据序列化
- `mbstring` — 多字节字符串
- `openssl` — 加密

上传限制调整（PHP → 配置修改）：
```ini
upload_max_filesize = 200M
post_max_size = 220M
max_execution_time = 300
```

---

## 功能特性

### 视觉
- XIAORAN极简黑白灰风格（参考 pan.suyanw.cn）
- 6 套主题一键切换（默认灰 / 紫晶 / 城市 / 扁平 / 现代 / 柔和）
- 通知轮播公告栏 + 广告轮播区
- 看板娘小挂件（24h 记住关闭状态）
- 安全运行时间计时器
- 友链展示区
- 弹窗系统（文件详情 / 分享链接 / 二维码 / 删除确认 / Toast）
- 完整响应式（桌面 / 平板 / 手机）

### S3 存储
- 零依赖纯 PHP + cURL（无需 Composer / AWS SDK）
- 完整 AWS Signature V4 签名
- 支持 AWS S3 / Cloudflare R2 / MinIO / 腾讯云 COS / 阿里云 OSS
- Path-Style 自动检测（R2 / MinIO）
- 断点续传 + 直传 POST Policy + 签名下载 URL

### 安全
- CSRF Token 防护
- 请求频率限制（Rate Limiting）
- 安全重定向（防 Open Redirect）
- IP 黑名单（支持 CIDR）
- 文件名安全过滤（防路径穿越）
- 安全 Session 启动（防固定攻击）
- 安全响应头（X-Content-Type-Options 等）

---

## 常见问题

### 覆盖后样式没变化？
- **浏览器缓存**：`Ctrl+Shift+R` 强制刷新，或开无痕窗口测试
- **CDN 缓存**：用了 CloudFlare/阿里云 CDN 需刷新 CDN 缓存
- **文件权限**：确认 `assets/css/style.css` 权限为 `644`

### 主题切换不生效？
- 确认浏览器未禁用 `localStorage`
- 检查 `header.php` 中主题切换 JS 是否正常加载

### 二维码不显示？
- 确认服务器能访问 `api.qrserver.com`
- 无外网时占位块仍然会显示

### 看板娘不出现？
- Cookie 可能已记录关闭状态，24h 后自动恢复
- 或手动清除 `kanban_hidden` cookie

### 如何还原？
```bash
# 从备份恢复
cp bak/日期/style.css assets/css/style.css
cp bak/日期/header.php includes/header.php
cp bak/日期/footer.php includes/footer.php
cp bak/日期/StorHelper.php includes/lib/StorHelper.php
cp bak/日期/login.php admin/login.php
cp bak/日期/set_stor.php admin/set_stor.php
```

或从 GitHub 重新下载 V5.6 原版覆盖：https://github.com/netcccyun/pan

---

## 主题配色

| 主题 | 强调色 | 特点 |
|------|--------|------|
| 默认 | `#4a4a4a` | 中性灰黑，朴素干净 |
| 紫水晶 | `#9b59b6` | 紫色系，优雅神秘 |
| 城市 | `#34495e` | 深蓝灰，沉稳商务 |
| 扁平 | `#1abc9c` | 青绿 + 无圆角 |
| 现代 | `#e74c3c` | 红色系，热情活力 |
| 柔和 | `#3498db` | 蓝色系，清爽流畅 |

主题选择保存在 `localStorage`，关闭浏览器不丢失。

---

美化 & 优化 by WorkBuddy · 2026
